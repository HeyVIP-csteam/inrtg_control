-- 工单表
CREATE TABLE IF NOT EXISTS tickets (
  id TEXT PRIMARY KEY,
  issue_type TEXT NOT NULL,
  user_id TEXT,
  contact TEXT,
  description TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',   -- open | resolved
  tg_message_id INTEGER,
  tg_chat_id TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- 回复表（TG群里的回复会写入这里）
CREATE TABLE IF NOT EXISTS replies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ticket_id TEXT NOT NULL,
  sender TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (ticket_id) REFERENCES tickets(id)
);

CREATE INDEX IF NOT EXISTS idx_tickets_tg_message_id ON tickets(tg_message_id);
CREATE INDEX IF NOT EXISTS idx_replies_ticket_id ON replies(ticket_id);
