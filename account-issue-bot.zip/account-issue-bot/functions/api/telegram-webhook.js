// POST /api/telegram-webhook
// Telegram 会把群里的新消息推送到这里（需要用 setWebhook 配置，见 README）

export async function onRequestPost(context) {
  const { request, env } = context;

  // 可选：用 secret token 校验请求确实来自 Telegram
  const secret = request.headers.get("X-Telegram-Bot-Api-Secret-Token");
  if (env.TELEGRAM_WEBHOOK_SECRET && secret !== env.TELEGRAM_WEBHOOK_SECRET) {
    return new Response("forbidden", { status: 403 });
  }

  let update;
  try {
    update = await request.json();
  } catch {
    return new Response("bad request", { status: 400 });
  }

  const msg = update.message;

  // 只处理「回复某条消息」的情况，忽略群里其他普通聊天
  if (!msg || !msg.reply_to_message) {
    return new Response("ok");
  }

  const repliedToId = msg.reply_to_message.message_id;

  const ticket = await env.DB.prepare(
    `SELECT id, status FROM tickets WHERE tg_message_id = ?`
  )
    .bind(repliedToId)
    .first();

  if (!ticket) {
    // 回复的不是我们的工单消息，忽略
    return new Response("ok");
  }

  const senderName = msg.from?.username ? `@${msg.from.username}` : msg.from?.first_name || "客服";
  const text = msg.text || "[非文本消息]";

  await env.DB.prepare(
    `INSERT INTO replies (ticket_id, sender, message) VALUES (?, ?, ?)`
  )
    .bind(ticket.id, senderName, text)
    .run();

  // 客服在群里回复时输入 /close 即可把工单标记为已解决
  if (text.trim().toLowerCase().startsWith("/close")) {
    await env.DB.prepare(`UPDATE tickets SET status = 'resolved' WHERE id = ?`)
      .bind(ticket.id)
      .run();
  }

  return new Response("ok");
}
