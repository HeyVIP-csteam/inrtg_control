// GET /api/ticket/:id
// 前端轮询这个接口，获取工单状态和 TG 群的回复

export async function onRequestGet(context) {
  const { params, env } = context;
  const ticketId = params.id;

  const ticket = await env.DB.prepare(`SELECT * FROM tickets WHERE id = ?`)
    .bind(ticketId)
    .first();

  if (!ticket) {
    return json({ error: "工单不存在" }, 404);
  }

  const replies = await env.DB.prepare(
    `SELECT sender, message, created_at FROM replies WHERE ticket_id = ? ORDER BY id ASC`
  )
    .bind(ticketId)
    .all();

  return json({ ticket, replies: replies.results });
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}
