// POST /api/submit
// 接收网页表单提交，写入 D1，并发送消息到 Telegram 群

export async function onRequestPost(context) {
  const { request, env } = context;

  try {
    const body = await request.json();
    const { issueType, userId, contact, description } = body;

    if (!issueType || !description) {
      return json({ error: "issueType 和 description 为必填项" }, 400);
    }

    const ticketId = generateTicketId();

    const text = buildTelegramText({ ticketId, issueType, userId, contact, description });

    const tgRes = await fetch(
      `https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: env.TELEGRAM_CHAT_ID,
          text,
          parse_mode: "HTML",
        }),
      }
    );
    const tgData = await tgRes.json();

    if (!tgData.ok) {
      return json({ error: "Telegram 消息发送失败", detail: tgData.description }, 502);
    }

    const tgMessageId = tgData.result.message_id;

    await env.DB.prepare(
      `INSERT INTO tickets (id, issue_type, user_id, contact, description, tg_message_id, tg_chat_id)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
      .bind(
        ticketId,
        issueType,
        userId || null,
        contact || null,
        description,
        tgMessageId,
        String(env.TELEGRAM_CHAT_ID)
      )
      .run();

    return json({ ticketId });
  } catch (err) {
    return json({ error: "服务器错误", detail: String(err) }, 500);
  }
}

function generateTicketId() {
  const ts = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `ACC-${ts}-${rand}`;
}

function buildTelegramText({ ticketId, issueType, userId, contact, description }) {
  return (
    `🟡 <b>新工单</b> #${ticketId}\n` +
    `类别: Account Issue - ${escapeHtml(issueType)}\n` +
    `用户ID: ${escapeHtml(userId || "未提供")}\n` +
    `联系方式: ${escapeHtml(contact || "未提供")}\n` +
    `描述: ${escapeHtml(description)}\n\n` +
    `↩️ 直接「回复」这条消息即可把内容同步回网页`
  );
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}
