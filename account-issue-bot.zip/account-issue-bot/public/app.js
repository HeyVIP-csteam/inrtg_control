const STORAGE_KEY = "account_issue_tickets";
const POLL_INTERVAL = 5000;

const form = document.getElementById("issue-form");
const formMsg = document.getElementById("form-msg");
const ticketList = document.getElementById("ticket-list");

const pollTimers = {};

// ---------- localStorage 里维护当前浏览器提交过的工单 ID 列表 ----------
function getStoredTicketIds() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch {
    return [];
  }
}

function addStoredTicketId(id) {
  const ids = getStoredTicketIds();
  if (!ids.includes(id)) {
    ids.unshift(id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
  }
}

// ---------- 提交表单 ----------
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const submitBtn = form.querySelector(".submit-btn");
  submitBtn.disabled = true;
  formMsg.textContent = "提交中...";
  formMsg.className = "form-msg";

  const payload = {
    issueType: document.getElementById("issueType").value,
    userId: document.getElementById("userId").value.trim(),
    contact: document.getElementById("contact").value.trim(),
    description: document.getElementById("description").value.trim(),
  };

  try {
    const res = await fetch("/api/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.error || "提交失败");
    }

    formMsg.textContent = `提交成功，工单号 ${data.ticketId}`;
    formMsg.className = "form-msg success";
    form.reset();

    addStoredTicketId(data.ticketId);
    renderTickets();
  } catch (err) {
    formMsg.textContent = err.message || "提交失败，请稍后重试";
    formMsg.className = "form-msg error";
  } finally {
    submitBtn.disabled = false;
  }
});

// ---------- 渲染 & 轮询工单 ----------
async function renderTickets() {
  const ids = getStoredTicketIds();

  if (ids.length === 0) {
    ticketList.innerHTML = `<p class="empty-state">暂无工单，提交后会显示在这里</p>`;
    return;
  }

  ticketList.innerHTML = "";
  for (const id of ids) {
    const el = document.createElement("div");
    el.className = "ticket";
    el.id = `ticket-${id}`;
    el.innerHTML = `<p class="no-reply">加载中...</p>`;
    ticketList.appendChild(el);
    fetchAndRenderTicket(id);
    startPolling(id);
  }
}

async function fetchAndRenderTicket(id) {
  try {
    const res = await fetch(`/api/ticket/${id}`);
    const data = await res.json();
    const el = document.getElementById(`ticket-${id}`);
    if (!el) return;

    if (!res.ok) {
      el.innerHTML = `<p class="no-reply">工单未找到（${id}）</p>`;
      stopPolling(id);
      return;
    }

    const { ticket, replies } = data;
    const isResolved = ticket.status === "resolved";

    el.innerHTML = `
      <div class="ticket-head">
        <span class="ticket-id">#${ticket.id}</span>
        <span class="status-pill ${isResolved ? "status-resolved" : "status-open"}">
          <span class="status-dot"></span>${isResolved ? "已解决" : "处理中"}
        </span>
      </div>
      <p class="ticket-type">${escapeHtml(ticket.issue_type)}</p>
      <div class="thread">
        ${
          replies.length === 0
            ? `<p class="no-reply">暂无客服回复</p>`
            : replies
                .map(
                  (r) => `
              <div class="reply">
                <span class="reply-sender">${escapeHtml(r.sender)}</span>
                <span class="reply-time">${formatTime(r.created_at)}</span>
                <div>${escapeHtml(r.message)}</div>
              </div>`
                )
                .join("")
        }
      </div>
    `;

    if (isResolved) stopPolling(id);
  } catch {
    // 网络错误时静默失败，下次轮询再试
  }
}

function startPolling(id) {
  if (pollTimers[id]) return;
  pollTimers[id] = setInterval(() => fetchAndRenderTicket(id), POLL_INTERVAL);
}

function stopPolling(id) {
  if (pollTimers[id]) {
    clearInterval(pollTimers[id]);
    delete pollTimers[id];
  }
}

function formatTime(str) {
  try {
    return new Date(str + "Z").toLocaleString("zh-CN", { hour12: false });
  } catch {
    return str;
  }
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

renderTickets();
